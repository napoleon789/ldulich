<div<?php print $attributes; ?>>
  <ul>
    <?php print $rendered_field_items; ?>
  </ul>
</div>
